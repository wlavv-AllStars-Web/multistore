<?php
if (!defined('_PS_VERSION_')) { exit; }

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_onepagecheckout}prestashop>order_30a3534b67a9a2c4cb3f1bb8659b321f'] = 'Very weak';
$_MODULE['<{ets_onepagecheckout}prestashop>layout_1_484f5a79672cebe198ebdde45a1d672f'] = 'Insured shipping';
$_MODULE['<{ets_onepagecheckout}prestashop>layout_2_484f5a79672cebe198ebdde45a1d672f'] = 'Insured shipping';
$_MODULE['<{ets_onepagecheckout}prestashop>layout_3_484f5a79672cebe198ebdde45a1d672f'] = 'Insured shipping';
$_MODULE['<{ets_onepagecheckout}prestashop>layout_4_484f5a79672cebe198ebdde45a1d672f'] = 'Insured shipping';
$_MODULE['<{ets_onepagecheckout}prestashop>login_30a3534b67a9a2c4cb3f1bb8659b321f'] = 'Very weak';
