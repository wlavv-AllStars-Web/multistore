<?php
include_once $_SERVER['DOCUMENT_ROOT'] . "/allstarsmotorsport/SCRIPTS/Helpers/inc.php";

function insert_data_into_ps_ukoocompat_compat($id_product){
    insert_data("INSERT INTO ps_ukoocompat_compat (id_product) VALUES ('" . $id_product . "')");
    return get_inserted_id('SELECT id_ukoocompat_compat FROM ps_ukoocompat_compat ORDER BY id_ukoocompat_compat DESC LIMIT 1', 'id_ukoocompat_compat')['id_ukoocompat_compat'];
}
function insert_data_into_ps_ukoocompat_compat_criterion($id_ukoocompat_compat, $id_ukoocompat_filter, $id_ikoocompat_criterion){    insert_data("INSERT INTO ps_ukoocompat_compat_criterion (id_ukoocompat_compat, id_ukoocompat_filter, id_ukoocompat_criterion) VALUES ('" . $id_ukoocompat_compat . "', '" . $id_ukoocompat_filter . "', '" . $id_ikoocompat_criterion . "')");
}
function get_id_ukoocompat_compat($id_product, $id_ukoocompat_criterion_1, $id_ukoocompat_criterion_2, $id_ukoocompat_criterion_3, $id_ukoocompat_criterion_4, $id_ukoocompat_criterion_5){
    $data['is_new'] = false;
    $sql = "SELECT * 
            FROM ps_ukoocompat_compat_criterion
            INNER JOIN ps_ukoocompat_compat
            ON ps_ukoocompat_compat_criterion.id_ukoocompat_compat = ps_ukoocompat_compat.id_ukoocompat_compat
            WHERE ps_ukoocompat_compat.id_ukoocompat_compat IN ( SELECT id_ukoocompat_compat 
                                         FROM ps_ukoocompat_compat_criterion 
                                         WHERE id_ukoocompat_filter = 1 AND id_ukoocompat_criterion = " . $id_ukoocompat_criterion_1 . ")
            AND ps_ukoocompat_compat.id_ukoocompat_compat IN ( SELECT id_ukoocompat_compat 
                                         FROM ps_ukoocompat_compat_criterion 
                                         WHERE id_ukoocompat_filter = 2 AND id_ukoocompat_criterion = " . $id_ukoocompat_criterion_2 . ")
            AND ps_ukoocompat_compat.id_ukoocompat_compat IN ( SELECT id_ukoocompat_compat 
                                         FROM ps_ukoocompat_compat_criterion 
                                         WHERE id_ukoocompat_filter = 3 AND id_ukoocompat_criterion = " . $id_ukoocompat_criterion_3 . ")
            AND ps_ukoocompat_compat.id_ukoocompat_compat IN ( SELECT id_ukoocompat_compat 
                                         FROM ps_ukoocompat_compat_criterion 
                                         WHERE id_ukoocompat_filter = 4 AND id_ukoocompat_criterion = " . $id_ukoocompat_criterion_4 . ")
            AND ps_ukoocompat_compat.id_ukoocompat_compat IN ( SELECT id_ukoocompat_compat 
                                         FROM ps_ukoocompat_compat_criterion 
                                         WHERE id_ukoocompat_filter = 5 AND id_ukoocompat_criterion = " . $id_ukoocompat_criterion_5 . ")
            AND id_product=" . $id_product;

    $conn = getConn();
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $data['is_new'] = 0;
    } else {
        $data['is_new'] = 1;
        $data['id_ukoocompat_compat'] = insert_data_into_ps_ukoocompat_compat($id_product);
    }

    return (object)$data;
}

/** Monta o array de compatibilidades simplificado **/
function simple_compatibility($select_1, $select_2, $select_3, $select_4){
    $compatibilities_filter['id_filter_value_1'] = $select_1;
    $compatibilities_filter['id_filter_value_2'] = $select_2;
    $compatibilities_filter['id_filter_value_3'] = $select_3;
    $compatibilities_filter['id_filter_value_4'] = $select_4;
    return (object)$compatibilities_filter;
}
/** Monta o array de compatibilidades ultidimensional **/
function nested_compatibility($select_1, $select_2, $select_3, $select_4){
    $main_sql = "SELECT * FROM ps_ukoocompat_compat_asm ";

    if ($select_1 != 0) $main_sql .= ' WHERE id_filter_value_1=' . $select_1;
    if ($select_2 != 0) $main_sql .= ' AND id_filter_value_2=' . $select_2;
    if ($select_3 != 0) $main_sql .= ' AND id_filter_value_3=' . $select_3;
    if ($select_4 != 0) $main_sql .= ' AND id_filter_value_4=' . $select_4;	
    $conn = getConn();
    $result = $conn->query($main_sql);
    $compatibilities_filter = array();

    while ($row = $result->fetch_assoc()) {
        $compatibilities_filter[] = (object)$row;
    }

    return $compatibilities_filter;
}

/** Devolve o array das compatibilidades **/
function get_compats($select_1, $select_2, $select_3, $select_4){	
    if (($select_1 != 0) && ($select_2 != 0) && ($select_3 != 0) && ($select_4 != 0)) {
        return simple_compatibility($select_1, $select_2, $select_3, $select_4);
    } else {
        return nested_compatibility($select_1, $select_2, $select_3, $select_4);
    }
}
$select_5 = (int)$_POST['select_5'];
$compats = (object)get_compats((int)$_POST['select_1'], (int)$_POST['select_2'], (int)$_POST['select_3'], (int)$_POST['select_4']);
$resposta = array();
$some_compats_existe = 0;
if ($select_5 > 0) {
    foreach ($compats As $k =>$compat) {						if ( !is_numeric( $compat) ){			$new_compat = get_id_ukoocompat_compat( $_POST['id_product'], $compat->id_filter_value_1, $compat->id_filter_value_2, $compat->id_filter_value_3, $compat->id_filter_value_4, $select_5 );			if ($new_compat->is_new) {				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 1, $compat->id_filter_value_1);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 2, $compat->id_filter_value_2);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 3, $compat->id_filter_value_3);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 4, $compat->id_filter_value_4);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 5, $select_5);			} else {				$some_compats_existe++;			}		}else{			$new_compat = get_id_ukoocompat_compat( $_POST['id_product'], $compats->id_filter_value_1, $compats->id_filter_value_2, $compats->id_filter_value_3, $compats->id_filter_value_4, $select_5 );
			if ($new_compat->is_new) {
				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 1, $compats->id_filter_value_1);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 2, $compats->id_filter_value_2);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 3, $compats->id_filter_value_3);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 4, $compats->id_filter_value_4);				insert_data_into_ps_ukoocompat_compat_criterion($new_compat->id_ukoocompat_compat, 5, $select_5);				
			} else {
				$some_compats_existe++;
			}		}
    }	
    $resposta['message'] = ($some_compats_existe > 0) ? 'Compatibilidades criadas com sucesso, note que algumas das compatibilidades que tentou inserir, já se encontram em base de dados!' : 'Compatibilidades criadas com sucesso!';
    $resposta['status'] = 1;
} else {
    $resposta['status'] = 0;
    $resposta['message'] = 'Por favor seleccione uma categoria!';
}

echo json_encode($resposta);