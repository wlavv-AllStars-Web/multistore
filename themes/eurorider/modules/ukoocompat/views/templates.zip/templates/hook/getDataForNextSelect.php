<?php

include_once $_SERVER['DOCUMENT_ROOT'] . "/allstarsmotorsport/SCRIPTS/Helpers/inc.php";

ini_set('max_execution_time', 600);

$select_1 = (int)$_POST['select_1'];
$select_2 = (int)$_POST['select_2'];
$select_3 = (int)$_POST['select_3'];
$nextSelect = (int)$_POST['nextSelect'];
$id_lang = (int)$_POST['id_lang'];

$id_parent_item =$select_1;
if($select_2 != 0) $id_parent_item = $select_2;
if($select_3 != 0) $id_parent_item = $select_3;

$sql = "SELECT ps_ukoocompat_criterion_lang.id_ukoocompat_criterion, ps_ukoocompat_criterion_lang.value 
        FROM ps_ukoocompat_criterion 
        INNER JOIN ps_ukoocompat_criterion_lang
        ON ps_ukoocompat_criterion_lang.id_ukoocompat_criterion = ps_ukoocompat_criterion.id_ukoocompat_criterion 
        WHERE id_ukoocompat_filter = " .  $nextSelect . " AND id_lang=" . $id_lang . " AND id_parent_item=" . $id_parent_item . "  OR parent_2=" . $id_parent_item . "  OR parent_3=" . $id_parent_item . "  OR parent_4=" . $id_parent_item . "  OR parent_5=" . $id_parent_item . " GROUP BY id_ukoocompat_criterion ORDER BY ps_ukoocompat_criterion_lang.value";


/**$sql = "SELECT ps_ukoocompat_criterion_lang.id_ukoocompat_criterion, ps_ukoocompat_criterion_lang.value 
        FROM ps_ukoocompat_criterion 
        INNER JOIN ps_ukoocompat_criterion_lang
        ON ps_ukoocompat_criterion_lang.id_ukoocompat_criterion = ps_ukoocompat_criterion.id_ukoocompat_criterion 
        WHERE id_ukoocompat_filter = " .  $nextSelect . " AND id_parent_item=" . $id_parent_item . " AND id_lang=" . $id_lang . ' ORDER BY ps_ukoocompat_criterion_lang.value';
**/
$conn = getConn();
$result = $conn->query($sql);

$html='<select name="id_ukoocompat_criterion_select_groups_[' . $nextSelect . ']" id="id_ukoocompat_criterion_select_groups_' . $nextSelect . '" onchange="call_ajax_fill_selects(' . $nextSelect . ')">';
$html.='<option value="0">Todas</option>';

while ($row = $result->fetch_assoc()) {
    $html.='<option value="' . $row['id_ukoocompat_criterion'] . '">' . $row['value'] . '</option>';
}
$html.='</select>';

echo $html;