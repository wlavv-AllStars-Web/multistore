<?php
class WmModuleHomepageMain extends ObjectModel{ }